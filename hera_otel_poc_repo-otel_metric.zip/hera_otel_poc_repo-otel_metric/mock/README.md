#HeraMock
HeraMock is more like wiremock for Hera. Since Hera works with its own protocol, wiremock won't work.
HeraMock is build with nginx&Lua combination. It uses python, redis for logging and debugging pages

#How to build
1. ./build.sh
2. It uses the example open SSL created keys
3. It builds both HeraMock, and it is java utility client which enables java applications to talk to HeraMock

#how to start
1. check Readme in docker_build_and_run