#!/bin/bash

ln -s $GOPATH/bin/mux .
ln -s $GOPATH/bin/mysqlworker .
