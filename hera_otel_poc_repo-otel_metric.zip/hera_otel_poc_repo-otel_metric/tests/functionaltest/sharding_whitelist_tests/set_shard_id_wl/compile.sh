go test -c ../../../../../../../github.com/paypal/hera/tests/functionaltest/sharding_whitelist_tests/set_shard_id_wl

