go test -c ../../../../../../../github.com/paypal/hera/tests/functionaltest/rac_tests/status_R_dedicated_worker
