go test -c ../../../../../../../github.com/paypal/hera/tests/functionaltest/sharding_tests/reset_shard_id

