package com.paypal.hera.cal;

import java.io.IOException;

public class CalTransaction {

	public void setName(String string) {
		// TODO Auto-generated method stub
		
	}

	public void addData(String string, String serverLogicalName) {
		// TODO Auto-generated method stub
		
	}

	public void setStatus(String string) {
		// TODO Auto-generated method stub
		
	}

	public void completed() {
		// TODO Auto-generated method stub
		
	}

	public String getCorrelationId() {
		// TODO Auto-generated method stub
		return "None";
	}

	public void setStatus(IOException e) {
		// TODO Auto-generated method stub
		
	}

}
