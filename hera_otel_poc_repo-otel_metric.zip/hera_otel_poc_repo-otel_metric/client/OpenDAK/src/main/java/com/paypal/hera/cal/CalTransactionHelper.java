package com.paypal.hera.cal;

public class CalTransactionHelper {

	public static CalTransaction getTopTransaction() {
		// TODO Auto-generated method stub
		return new CalTransaction();
	}

}
