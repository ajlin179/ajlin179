SQL driver for Hera, implementing basic operations as well as basic types (int, string).
