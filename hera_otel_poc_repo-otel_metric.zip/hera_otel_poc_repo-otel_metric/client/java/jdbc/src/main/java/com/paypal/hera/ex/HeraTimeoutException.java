package com.paypal.hera.ex;

@SuppressWarnings("serial")
public class HeraTimeoutException extends HeraExceptionBase {
	public HeraTimeoutException(String _message) {
		super(_message);
	}
}
