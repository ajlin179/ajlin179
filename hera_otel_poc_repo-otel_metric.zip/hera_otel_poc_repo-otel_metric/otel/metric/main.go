package metric

import (
	"context"
	"fmt"
	"log"
	"net/http"
	_ "runtime/debug"
	"strconv"
	"strings"
	"time"

	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/exporters/otlp/otlpmetric"
	"go.opentelemetry.io/otel/exporters/otlp/otlpmetric/otlpmetrichttp"
	"go.opentelemetry.io/otel/exporters/prometheus"
	"go.opentelemetry.io/otel/metric"
	"go.opentelemetry.io/otel/metric/global"
	"go.opentelemetry.io/otel/metric/instrument"
	"go.opentelemetry.io/otel/sdk/metric/aggregator/histogram"
	controller "go.opentelemetry.io/otel/sdk/metric/controller/basic"
	"go.opentelemetry.io/otel/sdk/metric/export/aggregation"
	processor "go.opentelemetry.io/otel/sdk/metric/processor/basic"
	"go.opentelemetry.io/otel/sdk/metric/selector/simple"
	selector "go.opentelemetry.io/otel/sdk/metric/selector/simple"
	"go.opentelemetry.io/otel/sdk/resource"
	semconv "go.opentelemetry.io/otel/semconv/v1.4.0"
)

var (
	ctlr     *controller.Controller
	exporter *otlpmetric.Exporter
	meter    metric.Meter
)

var acceptState int64

func init() {

	meter := configureotelsfx()

	//	meter := configurePoromo()
	fmt.Println("----------Meter------------------------")
	fmt.Println(meter)

	gauge, _ := meter.AsyncInt64().Gauge(
		"test-acpt-gauge",
		// instrument.WithUnit("1"),
		// instrument.WithDescription("TODO"),
	)

	if err := meter.RegisterCallback(
		[]instrument.Asynchronous{
			gauge,
		},
		func(ctx context.Context) {
			fmt.Println("Gauge::" + time.Now().String())
			// debug.PrintStack()
			gauge.Observe(ctx, readAcceptStateFromStatelog())
		},
	); err != nil {
		panic(err)
	}

}

func readAcceptStateFromStatelog() int64 {
	return acceptState
}

func PublishStatelog(statelogFmt string) {
	// fmt.Print(_name + "::")
	// fmt.Println(_value)
	// if _name == "acpt" {
	// 	acceptState = _value
	// }

	fmt.Println(statelogFmt)
	tokens := strings.Fields(statelogFmt)
	fmt.Println(tokens, len(tokens))
	acceptState, _ = strconv.ParseInt(tokens[2], 10, 64)
	fmt.Println(acceptState)

}

func configureotelsfx() metric.Meter {
	// config := .Config{}
	var err error

	client := otlpmetrichttp.NewClient(
		otlpmetrichttp.WithInsecure(),
	//	otlpmetrichttp.WithEndpoint("192.168.1.161:4318"),

	)
	ctx := context.Background()
	exporter, err := otlpmetric.New(ctx, client)

	resource := resource.NewWithAttributes(
		semconv.SchemaURL,
		semconv.ServiceNameKey.String("hera-otelpoc"),
		semconv.ServiceVersionKey.String("1.0.0"),
		semconv.DeploymentEnvironmentKey.String("devpoc"),
		attribute.Int64("ID", 1234),
	)

	ctlr = controller.New(
		processor.NewFactory(
			simple.NewWithInexpensiveDistribution(),
			aggregation.CumulativeTemporalitySelector(),
			processor.WithMemory(true),
		),
		controller.WithExporter(exporter),
		controller.WithResource(resource),
	)

	if err != nil {
		log.Panicf("failed to initialize otlp exporter %v", err)
	}

	// global.SetMeterProvider(exporter.MeterProvider())

	meter := ctlr.Meter("test-meter")
	ctlr.Start(ctx)
	return meter

}

func configurePoromo() metric.Meter {
	fmt.Println("----------configurePoromo------------")
	config := prometheus.Config{}

	resource := resource.NewWithAttributes(
		semconv.SchemaURL,
		semconv.ServiceNameKey.String("hera-promopoc"),
		semconv.ServiceVersionKey.String("1.0.0"),
		semconv.DeploymentEnvironmentKey.String("devpoc"),
		attribute.Int64("ID", 1234),
	)

	ctlr = controller.New(
		processor.NewFactory(
			selector.NewWithHistogramDistribution(
				histogram.WithExplicitBoundaries(config.DefaultHistogramBoundaries),
			),
			aggregation.CumulativeTemporalitySelector(),
			processor.WithMemory(true),
		),
		controller.WithResource(resource),
	)

	exporter, err := prometheus.New(config, ctlr)
	fmt.Println("----------Exporter------------")
	fmt.Println(exporter)

	if err != nil {
		log.Panicf("failed to initialize prometheus exporter %v", err)
	}

	global.SetMeterProvider(exporter.MeterProvider())

	meter = exporter.MeterProvider().Meter("github.com/banked/gopherconuk2021/demo5")
	fmt.Println("----------Meter------------")
	fmt.Println(exporter)

	http.HandleFunc("/metrics", exporter.ServeHTTP)
	fmt.Println("listenening on http://localhost:8088/metrics")

	go func() {
		_ = http.ListenAndServe(":8088", nil)
	}()

	ctx := context.Background()
	ctlr.Start(ctx)

	return meter

}
