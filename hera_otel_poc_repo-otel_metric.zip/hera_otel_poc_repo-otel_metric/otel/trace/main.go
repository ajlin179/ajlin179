package trace

import (
	"context"
	"fmt"

	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/exporters/jaeger"
	"go.opentelemetry.io/otel/exporters/otlp/otlptrace"
	"go.opentelemetry.io/otel/exporters/otlp/otlptrace/otlptracehttp"
	"go.opentelemetry.io/otel/propagation"
	"go.opentelemetry.io/otel/sdk/resource"
	sdktrace "go.opentelemetry.io/otel/sdk/trace"
	semconv "go.opentelemetry.io/otel/semconv/v1.4.0"
	"go.opentelemetry.io/otel/trace"
)

var tracer trace.Tracer

func init() {
	ctx := context.Background()
	// exp, err := newExporterOtelSfx(ctx)
	exp, err := newExporterJaeger(ctx)
	if err != nil {
		fmt.Println(err)
		fmt.Println("failed to initialize exporter:")
		fmt.Println(err)
	}
	fmt.Println(exp)

	// tp := newTraceProvider(exp)
	tp := newTraceProviderJaeger(exp)

	fmt.Println(tp)

	// defer func() { _ = tp.Shutdown(ctx) }()

	otel.SetTracerProvider(tp)

	otel.SetTextMapPropagator(
		propagation.NewCompositeTextMapPropagator(
			propagation.TraceContext{},
			propagation.Baggage{},
		),
	)

	tracer = otel.GetTracerProvider().Tracer("heraworkertrace")

}

func newExporterOtelSfx(ctx context.Context) (*otlptrace.Exporter, error) {
	client := otlptracehttp.NewClient(otlptracehttp.WithInsecure())
	return otlptrace.New(ctx, client)
}

func newExporterJaeger(ctx context.Context) (*jaeger.Exporter, error) {

	exp, err := jaeger.New(jaeger.WithCollectorEndpoint())
	if err != nil {
		panic(err)
	}
	return exp, err

}

func newTraceProvider(exp *otlptrace.Exporter) *sdktrace.TracerProvider {
	resource :=
		resource.NewWithAttributes(
			semconv.SchemaURL,
			semconv.ServiceNameKey.String("heramyserv"),
			semconv.ServiceVersionKey.String("1.0.0"),
			semconv.DeploymentEnvironmentKey.String("qa"),
		)

	return sdktrace.NewTracerProvider(
		sdktrace.WithBatcher(exp),
		sdktrace.WithResource(resource),
	)
}

func newTraceProviderJaeger(exp *jaeger.Exporter) *sdktrace.TracerProvider {
	resource :=
		resource.NewWithAttributes(
			semconv.SchemaURL,
			semconv.ServiceNameKey.String("heramyserv"),
			semconv.ServiceVersionKey.String("1.0.0"),
			semconv.DeploymentEnvironmentKey.String("qa"),
		)

	return sdktrace.NewTracerProvider(
		sdktrace.WithBatcher(exp),
		sdktrace.WithResource(resource),
	)
}

func StartSpan(ctx context.Context, spanName string) (context.Context, trace.Span) {
	ctxSpan, span := tracer.Start(ctx, spanName)
	return ctxSpan, span
}

func EndSpan(span trace.Span) {
	span.End()
}
