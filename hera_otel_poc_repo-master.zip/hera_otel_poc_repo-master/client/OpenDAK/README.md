# OpenDAK
Open Data Access Kernel for Hera. Currently available for Java clients.


