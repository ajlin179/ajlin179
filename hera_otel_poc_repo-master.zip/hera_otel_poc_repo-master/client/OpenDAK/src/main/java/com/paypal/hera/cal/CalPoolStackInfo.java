package com.paypal.hera.cal;

public class CalPoolStackInfo {

	public static CalPoolStackInfo getCalPoolStackInfo() {
		return new CalPoolStackInfo();
	}

	// TODO: implement
	public String getPoolStack() {
		return "None";
	}

}
