package com.paypal.hera.cal;

import java.sql.SQLException;

public class StackTrace {

	public static String getStackTrace(SQLException e) {
		// TODO Auto-generated method stub
		return "N/A";
	}

}
