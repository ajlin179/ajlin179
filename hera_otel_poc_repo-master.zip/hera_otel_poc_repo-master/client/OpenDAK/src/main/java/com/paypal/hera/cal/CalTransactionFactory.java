package com.paypal.hera.cal;

public class CalTransactionFactory {

	public static CalTransaction create(String string) {
		// TODO Auto-generated method stub
		return new CalTransaction();
	}

}
