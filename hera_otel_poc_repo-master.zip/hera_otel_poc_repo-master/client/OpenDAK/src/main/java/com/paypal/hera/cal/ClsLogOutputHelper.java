package com.paypal.hera.cal;

public class ClsLogOutputHelper {

	public static long writeSQLStmt(String sql) {
		// TODO Auto-generated method stub
		return 0;
	}

}
