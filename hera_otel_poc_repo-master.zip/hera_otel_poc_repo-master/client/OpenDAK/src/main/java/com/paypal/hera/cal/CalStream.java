package com.paypal.hera.cal;

public class CalStream {
	static CalStream Instance = new CalStream();

	public CalTransaction transaction(String string) {
		// TODO Auto-generated method stub
		return new CalTransaction();
	}
}
