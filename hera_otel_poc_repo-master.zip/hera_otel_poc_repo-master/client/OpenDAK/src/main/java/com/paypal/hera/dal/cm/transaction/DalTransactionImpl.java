package com.paypal.hera.dal.cm.transaction;

public class DalTransactionImpl {
	// Place holder. Tx not supported. Later on we can support Hybrid Tx
}
