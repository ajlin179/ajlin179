package com.paypal.hera.ex;

@SuppressWarnings("serial")
public class HeraInternalErrorException extends HeraExceptionBase {

	public HeraInternalErrorException(String message) {
		super(message);
	}

}
