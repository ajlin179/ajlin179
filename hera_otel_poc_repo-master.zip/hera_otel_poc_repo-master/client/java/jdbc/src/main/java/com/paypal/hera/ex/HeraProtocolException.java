package com.paypal.hera.ex;

@SuppressWarnings("serial")
public class HeraProtocolException extends HeraExceptionBase {
	public HeraProtocolException(String _message) {
		super(_message);
	}
}
