Go SQL driver for the Hera server
With basic tls
