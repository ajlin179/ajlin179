
# History of Hera

Hera started as Oracle Connection Cache (occ) in PayPal's early days.  As 
PayPal faced scaling challenges, we started rewriting large portions of 
occ to add multiplexing and sharding.  Hera is the go programming language
version.

