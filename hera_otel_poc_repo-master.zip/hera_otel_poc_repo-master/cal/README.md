As of May 2019, we would like to explore evolution of cal.  There's background and
on https://github.com/paypal/hera/issues/25
