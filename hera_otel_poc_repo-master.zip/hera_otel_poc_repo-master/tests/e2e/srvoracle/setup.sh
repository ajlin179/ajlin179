#!/bin/bash

#export TWO_TASK=
#export LD_LIBRAY_PATH=<oracle lib path>:$LD_LIBRAY_PATH

ln -s $GOPATH/bin/mux .
ln -s $GOPATH/bin/oracleworker .
