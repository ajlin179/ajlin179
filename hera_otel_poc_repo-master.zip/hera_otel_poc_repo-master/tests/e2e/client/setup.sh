#!/bin/bash

ln -s $GOPATH/bin/client .
