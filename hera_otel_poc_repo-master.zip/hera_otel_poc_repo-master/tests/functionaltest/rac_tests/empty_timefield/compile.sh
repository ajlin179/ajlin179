go test -c ../../../../../../../github.com/paypal/hera/tests/functionaltest/rac_tests/empty_timefield
