go test -c ../../../../../../../github.com/paypal/hera/tests/functionaltest/rac_tests/status_R_Tcurr_GT_Tsch_and_Tsch_LT_Tstart
