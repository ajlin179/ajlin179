go test -c ../../../../../../../github.com/paypal/hera/tests/functionaltest/rac_tests/status_F_Tcurr_GT_Tsch
