go test -c ../../../../../../../github.com/paypal/hera/tests/functionaltest/rac_tests/rac_restart_window_R
