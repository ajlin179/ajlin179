go test -c ../../../../../../../github.com/paypal/hera/tests/functionaltest/bind_eviction_tests/simple_evict
