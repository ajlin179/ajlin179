go test -c ../../../../../../../github.com/paypal/hera/tests/functionaltest/root_transaction_tests/InitDBError
