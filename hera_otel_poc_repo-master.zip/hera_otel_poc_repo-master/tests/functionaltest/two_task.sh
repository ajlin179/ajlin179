export TWO_TASK='tcp(172.17.0.2:3115)/heratestdb?timeout=9s&tls=preferred&clientFoundRows=true'
export username=mysql11
export password=1-testDb
export DB_USER=$username
export DB_PASSWORD=$password
export DB_DATASOURCE=$TWO_TASK
