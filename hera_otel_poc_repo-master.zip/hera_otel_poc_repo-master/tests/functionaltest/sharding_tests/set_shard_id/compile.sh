go test -c ../../../../../../../github.com/paypal/hera/tests/functionaltest/sharding_tests/set_shard_id

