go test -c ../../../../../../../github.com/paypal/hera/tests/functionaltest/coordinator_tests/num_polls_before_activation
